using Microsoft.AspNetCore.Mvc;
namespace Portfolio
{
    public class IndexController : Controller
    {
        [Route("")]
        [HttpGet]
        public string Index()
        {
            return "This is my Index";
        }
        [Route("Projects")]
        [HttpGet]
        public string Projects()
        {
            return "These are my Projects!";
        }
        [Route("Contacts")]
        [HttpGet]
        public string Contacts()
        {
            return "These are my contacts!";
        }
    }
}
 